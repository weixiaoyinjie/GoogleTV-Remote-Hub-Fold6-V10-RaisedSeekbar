# Google TV Remote Hub · Fold6 V10 Raised Seekbar

基于上传的 Fold6 V9 Seekbar 源码。两个控制面板同时上移；保留所有圆形按钮、白色镂空图标、细灰圆边、按键映射及电视配对机制。正常竖屏和大屏：进度区域高 84dp、距内容底部 36dp，拖动触控高度 56dp；短屏（可用高度小于 420dp）：进度区域高 76dp、底部留 16dp，拖动触控高度 48dp（像素取整可能有约 1px 差异）。可见横线为 12dp，圆形滑块直径 28dp。面板根据剩余区域重新计算正圆几何，较矮视口的按钮可能略缩小，不会与进度条重叠。点击或拖动松手发送实际定位指令，拖动中显示目标时间；原进度协议、轮询、取消/多指处理不变。电视端助手源码完全不变，已安装 V9 电视助手可继续使用。

## 使用
手机端安装 `fold6-phone-debug.apk`，仍从 TV 遥控 / TV 媒体进入，使用原设置里的电视 IP。右上设置 → 播放进度设置：

### Kodi 直连（默认）
电视 Kodi → 设置 → 服务 → 控制 → 允许其他系统的应用远程控制（Allow remote control from applications on other systems）。使用同一电视 IP、Kodi JSON-RPC TCP 默认 9090 端口，不需要安装额外电视 APK。Kodi 必须正在播放一个支持定位的影音项目。此 TCP 服务不需要密码，仅在可信局域网开启，勿对公网开放。非 Kodi 播放器不能通过此模式定位。适用 Kodi JSON-RPC v12 的 Player.Seek 百分比参数。

### TV 助手（可选，用于其他播放器）
1. 将编译产物 `tv-seek-bridge-debug.apk` 安装到 Google TV，而不是手机。打开 TV 进度助手。
2. 点击打开通知访问设置，允许 TV 进度助手访问通知。某些电视没有此设置界面或限制该权限，需电视本身支持。开发者可在已授权的 ADB 连接上尝试：
   `adb shell cmd notification allow_listener com.cecbridge.remotev2.seekbridge/com.cecbridge.remotev2.bridge.MediaBridgeService`
   此命令可能受系统版本限制；不要绕过不允许授权的设备政策。
3. 手机右上设置 → 播放进度设置 → TV 助手，输入电视显示的 32 位验证码，保存。使用同一个电视 IP，局域网 TCP 18766。
4. 电视开始播放影音。助手通过 Android MediaSession 读取进度，只有播放器提供有效总时长、项目标识和 ACTION_SEEK_TO 时才启用。YouTube、Netflix、Qobuz 等是否可用取决于实际应用版本及其媒体会话；直播、广告或不公开进度的播放器不能保证定位。如果多个播放会话都活跃，暂停控制以免误操作。助手只请求定位，下一次刷新才确认播放器实际状态；不会模拟进度。
5. 不需要时可关闭进度控制并撤销电视助手通知访问权限或卸载助手。助手由系统绑定，电视系统休眠或限制后台时可能断开。

助手使用每次连接随机挑战和 HMAC-SHA256 验证命令与响应，不传输验证码或通知内容；进度数据与应用包名未加密，仅在可信局域网使用，不要映射端口到互联网。手机端轮询仅在前台执行，独立线程不阻塞旧遥控按键。

## 原功能及安装
- 保留 V9 的 PairingClient.java、IdentityStore.java、RemoteSession.java、Proto.java 原文件，以及 Google TV 6466/6467 配对连接与按键映射。进度走独立连接。
- 手机 applicationId `com.cecbridge.remotev2.phone`，versionCode 10；助手为独立包 `com.cecbridge.remotev2.seekbridge`。签名与原 V9 相同时可覆盖安装并保留配对数据；GitHub 新仓库临时 debug 签名可能不同，需要卸载旧版再安装和配对。旧版 APK 未修改。

## GitHub 编译（ZIP 不解压）
1. 新建仓库 `GoogleTV-Remote-Hub-Fold6-V10-RaisedSeekbar`。
2. 上传 `GoogleTV-Remote-Hub-Fold6-V10-RaisedSeekbar-OneUpload.zip` 至仓库根目录。
3. 新建 `.github/workflows/build-apk.yml`，复制随附独立编译文件内容。
4. Actions → Build Google TV Remote Fold6 V10 Raised Seekbar APK → Run workflow。
5. 下载 `GoogleTV-Remote-Hub-Fold6-V10-RaisedSeekbar-APK`，包含手机 `fold6-phone-debug.apk` 和可选电视 `tv-seek-bridge-debug.apk`。

## 验证范围
原圆形几何 8,405 组、手机几何 / V9 底部预留 / V10 新进度区域各 35,574 组模拟测试通过（边界、互不重叠、命中、中央控制轮上移与触控区域高度）。当前环境没有 Android SDK/Gradle，尚未完整编译 V10 APK，实际屏幕显示与电视定位须真机确认。工作流先执行几何测试再编译两个 APK。

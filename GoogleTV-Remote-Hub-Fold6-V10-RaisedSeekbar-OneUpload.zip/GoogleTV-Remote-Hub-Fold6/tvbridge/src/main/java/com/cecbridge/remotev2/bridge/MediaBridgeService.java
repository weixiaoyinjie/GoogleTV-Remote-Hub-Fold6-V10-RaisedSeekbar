package com.cecbridge.remotev2.bridge;

import android.content.ComponentName;
import android.media.MediaMetadata;
import android.media.session.*;
import android.os.SystemClock;
import android.service.notification.NotificationListenerService;
import java.net.*;
import java.util.*;
import org.json.JSONObject;
import com.cecbridge.remotev2.seek.BridgeWire;

public final class MediaBridgeService extends NotificationListenerService {
    private volatile ServerSocket server;
    private final Map<MediaSession.Token,String> tokens=new HashMap<>();
    @Override public synchronized void onListenerConnected(){super.onListenerConnected();stopServer();
        try{ServerSocket listener=new ServerSocket();listener.setReuseAddress(true);listener.bind(new InetSocketAddress(BridgeWire.PORT));server=listener;
            Thread t=new Thread(()->loop(listener),"tv-timeline");t.setDaemon(true);t.start();
        }catch(Exception ignored){}
    }
    private void loop(ServerSocket listener){while(server==listener&&!listener.isClosed()){
        try(Socket s=listener.accept()){if(server!=listener)return;BridgeWire.serve(s,BridgeActivity.secret(this),req->{if(server!=listener)throw new IllegalStateException();return handle(req);});}
        catch(Exception ignored){}
    }}
    private synchronized void stopServer(){ServerSocket old=server;server=null;if(old!=null)try{old.close();}catch(Exception ignored){}}
    @Override public void onListenerDisconnected(){stopServer();super.onListenerDisconnected();}
    @Override public void onDestroy(){stopServer();super.onDestroy();}
    private static final class Current {MediaController controller;JSONObject info;}
    private static JSONObject empty(String message)throws Exception{return new JSONObject().put("message",message).put("seekable",false);}
    private synchronized Current current()throws Exception{
        Current result=new Current();MediaSessionManager manager=getSystemService(MediaSessionManager.class);
        List<MediaController> all=manager.getActiveSessions(new ComponentName(this,MediaBridgeService.class));
        List<MediaController> active=new ArrayList<>(),paused=new ArrayList<>();Set<MediaSession.Token> present=new HashSet<>();
        for(MediaController c:all){present.add(c.getSessionToken());PlaybackState p=c.getPlaybackState();if(p==null)continue;
            int state=p.getState();if(state==PlaybackState.STATE_PLAYING||state==PlaybackState.STATE_BUFFERING||state==PlaybackState.STATE_FAST_FORWARDING||state==PlaybackState.STATE_REWINDING)active.add(c);
            else if(state==PlaybackState.STATE_PAUSED)paused.add(c);}
        tokens.keySet().retainAll(present);
        List<MediaController> candidates=active.isEmpty()?paused:active;
        if(candidates.size()!=1){result.info=empty(candidates.isEmpty()?"电视未播放影音":"电视有多个播放会话");return result;}
        MediaController c=candidates.get(0);PlaybackState p=c.getPlaybackState();MediaMetadata m=c.getMetadata();
        if(p==null||m==null){result.info=empty("播放器未提供进度");return result;}
        long duration=m.getLong(MediaMetadata.METADATA_KEY_DURATION),pos=p.getPosition();
        if(pos>=0&&p.getState()==PlaybackState.STATE_PLAYING&&p.getLastPositionUpdateTime()>0)pos+=(long)(Math.max(0,SystemClock.elapsedRealtime()-p.getLastPositionUpdateTime())*p.getPlaybackSpeed());
        String token=tokens.get(c.getSessionToken());if(token==null){token=BridgeWire.randomHex();tokens.put(c.getSessionToken(),token);}
        String mediaId=m.getString(MediaMetadata.METADATA_KEY_MEDIA_ID),title=m.getString(MediaMetadata.METADATA_KEY_TITLE),artist=m.getString(MediaMetadata.METADATA_KEY_ARTIST);
        boolean identified=(mediaId!=null&&!mediaId.isEmpty())||(title!=null&&!title.isEmpty());
        // No notification content or title leaves the TV: only a keyed opaque item fingerprint.
        String id=BridgeWire.sign(BridgeActivity.secret(this),token+"\n"+mediaId+"\n"+title+"\n"+artist+"\n"+duration+"\n"+p.getActiveQueueItemId());
        boolean seek=identified&&duration>0&&pos>=0&&(p.getActions()&PlaybackState.ACTION_SEEK_TO)!=0;
        result.controller=c;result.info=new JSONObject().put("id",id).put("source",c.getPackageName()).put("position",Math.max(0,Math.min(pos,duration))).put("duration",Math.max(0,duration)).put("seekable",seek).put("message",seek?"":"播放器不开放定位");return result;
    }
    private JSONObject handle(JSONObject req)throws Exception{
        Current c=current();String op=req.optString("op");if("status".equals(op))return c.info;
        if(!"seek".equals(op)||c.controller==null||!c.info.optBoolean("seekable")||!c.info.optString("id").equals(req.optString("id")))return empty("播放项目已变化或不允许定位");
        long target=req.getLong("position");if(target<0||target>c.info.getLong("duration"))return empty("无效时间");
        c.controller.getTransportControls().seekTo(target);
        // This acknowledges dispatch, not playback position; the next poll reads actual state.
        return c.info.put("accepted",true);
    }
}

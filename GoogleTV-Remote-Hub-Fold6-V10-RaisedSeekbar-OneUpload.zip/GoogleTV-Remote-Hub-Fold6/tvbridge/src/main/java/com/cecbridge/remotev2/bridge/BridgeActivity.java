package com.cecbridge.remotev2.bridge;
import android.app.Activity;
import android.content.*;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;
import com.cecbridge.remotev2.seek.BridgeWire;

public final class BridgeActivity extends Activity {
    static synchronized String secret(Context c){
        android.content.SharedPreferences p=c.getSharedPreferences("bridge",MODE_PRIVATE);
        String s=p.getString("secret","");if(s.isEmpty()){s=BridgeWire.randomHex();p.edit().putString("secret",s).commit();}return s;
    }
    @Override public void onCreate(Bundle b){super.onCreate(b);LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(48,36,48,36);
        TextView text=new TextView(this);text.setTextSize(22);text.setText("TV 进度助手\n\n仅用于读取和定位当前媒体播放进度。\n请允许通知访问权限（不会向手机发送通知内容）。\n手机遥控设置 → 播放进度 → TV 助手 → 输入下方验证码。\n仅在可信局域网使用。\n\n验证码：\n"+secret(this));root.addView(text);
        Button enable=new Button(this);enable.setText("打开通知访问设置");root.addView(enable);enable.setOnClickListener(v->{try{startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));}catch(Exception ex){Toast.makeText(this,"此电视没有通知访问页面，请查看安装说明中的 ADB 方法",Toast.LENGTH_LONG).show();}});
        Button rotate=new Button(this);rotate.setText("更换验证码");root.addView(rotate);rotate.setOnClickListener(v->{getSharedPreferences("bridge",MODE_PRIVATE).edit().putString("secret",BridgeWire.randomHex()).commit();recreate();});
        setContentView(root);
    }
}

package com.cecbridge.remotev2.seek;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.json.JSONObject;

/** Per-connection challenge, authenticated requests and replies. No secret is sent on the wire. */
public final class BridgeWire {
    public static final int PORT=18766;
    private static final SecureRandom RANDOM=new SecureRandom();
    public static String randomHex(){byte[] b=new byte[16];RANDOM.nextBytes(b);return hex(b);}
    private static String hex(byte[] bytes){StringBuilder s=new StringBuilder();for(byte b:bytes)s.append(String.format(java.util.Locale.ROOT,"%02x",b&255));return s.toString();}
    public static String sign(String key,String value)throws Exception{
        Mac m=Mac.getInstance("HmacSHA256");m.init(new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8),"HmacSHA256"));return hex(m.doFinal(value.getBytes(StandardCharsets.UTF_8)));
    }
    public static boolean verify(String key,String value,String signature)throws Exception{
        return MessageDigest.isEqual(sign(key,value).getBytes(StandardCharsets.US_ASCII),signature.getBytes(StandardCharsets.US_ASCII));
    }
    public static JSONObject call(String host,String key,JSONObject request)throws Exception{
        try(Socket s=new Socket()){
            s.connect(new InetSocketAddress(host,PORT),1000);s.setSoTimeout(1800);
            DataInputStream in=new DataInputStream(s.getInputStream());DataOutputStream out=new DataOutputStream(s.getOutputStream());
            String nonce=in.readUTF();if(!nonce.matches("[0-9a-f]{32}"))throw new IOException("无效电视响应");
            String body=request.toString();out.writeUTF(body);out.writeUTF(sign(key,"request\n"+nonce+"\n"+body));out.flush();
            String reply=in.readUTF(),sig=in.readUTF();if(!verify(key,"reply\n"+nonce+"\n"+reply,sig))throw new IOException("电视验证码错误");
            return new JSONObject(reply);
        }
    }
    public interface Handler{JSONObject handle(JSONObject request)throws Exception;}
    public static void serve(Socket s,String key,Handler handler)throws Exception{
        s.setSoTimeout(1800);DataInputStream in=new DataInputStream(s.getInputStream());DataOutputStream out=new DataOutputStream(s.getOutputStream());
        String nonce=randomHex();out.writeUTF(nonce);out.flush();String body=in.readUTF(),sig=in.readUTF();
        if(!verify(key,"request\n"+nonce+"\n"+body,sig))return;
        JSONObject response;
        try{response=handler.handle(new JSONObject(body));}catch(Exception ex){response=new JSONObject().put("message","电视无法读取或控制当前播放器");}
        String reply=response.toString();out.writeUTF(reply);out.writeUTF(sign(key,"reply\n"+nonce+"\n"+reply));out.flush();
    }
}

package com.cecbridge.remotev2;

public final class PhoneGeometryTest {
    private static void check(boolean b,String s){if(!b)throw new AssertionError(s);}
    public static void main(String[] args){
        int cases=0;
        for(int w=240;w<=1000;w+=10)for(int h=240;h<=1000;h+=10)
            for(float d:new float[]{1,1.5f,2,2.75f,3,3.5f}){
                test(w*d,h*d,d);testFooter(w*d,h*d,d);testRaisedFooter(w*d,h*d,d);cases++;
            }
        System.out.println("Phone viewport checks passed: "+cases+" cases");
        for(int[] dim:new int[][]{{320,690},{344,790},{360,800},{673,760},{720,800},{760,673},{800,360},{320,450}}){
            PhonePanelGeometry g=test(dim[0],dim[1],1);
            float min=Float.MAX_VALUE,max=0;for(float r:g.r){min=Math.min(min,r);max=Math.max(max,r);}
            System.out.printf("%dx%d dp: %s; wheel %.1f, OK %.1f, peripheral %.1f–%.1f dp diameters%n",dim[0],dim[1],g.tall?"cover layout":"radial layout",g.wheel*2,g.ok*2,min*2,max*2);
            if(Math.min(dim[0],dim[1])>=320 && dim[1]>=1.55*dim[0])check(min*2>=48,"cover touch target");
        }
    }
    private static void testRaisedFooter(float w,float h,float d){
        int footer=PhonePanelGeometry.footerHeight(h,d),lift=PhonePanelGeometry.footerLift(h,d);
        float panelH=h-footer-lift,edge=8*d,eps=.02f;
        PhonePanelGeometry old=PhonePanelGeometry.withFooter(w,h,edge,2*d,56*d);
        PhonePanelGeometry g=test(w,panelH,d);
        check(g.cy<old.cy,"wheel must move upward");
        check(g.cy+g.wheel<=panelH-edge+eps,"wheel must clear footer");
        for(int i=0;i<9;i++)check(g.y[i]+g.r[i]<=panelH-edge+eps,"key must clear footer");
        check(footer-Math.round(24*d)-Math.round(4*d)>=48*d-2,"minimum touch height");
        check(lift>=16*d-1,"bottom safe space");
    }
    private static void testFooter(float w,float h,float d){
        float edge=8*d,footer=56*d,eps=.02f;
        PhonePanelGeometry g=PhonePanelGeometry.withFooter(w,h,edge,2*d,footer);
        check(g.wheel>0&&g.ok>0,"footer wheel");
        check(g.cy+g.wheel<=h-footer-edge+eps&&g.cy-g.wheel>=edge-eps,"footer wheel bounds");
        for(int i=0;i<9;i++){
            check(g.r[i]>0&&g.y[i]+g.r[i]<=h-footer-edge+eps&&g.y[i]-g.r[i]>=edge-eps,"footer key bounds");
            check(g.x[i]+g.r[i]<=w-edge+eps&&g.x[i]-g.r[i]>=edge-eps,"footer key width");
            check(g.hitKey(g.x[i],g.y[i])==i,"footer hit");
            check(Math.hypot(g.x[i]-g.cx,g.y[i]-g.cy)>=g.r[i]+g.wheel+g.gap-eps,"footer wheel collision");
            for(int j=i+1;j<9;j++)check(Math.hypot(g.x[i]-g.x[j],g.y[i]-g.y[j])>=g.r[i]+g.r[j]+g.gap-eps,"footer key collision");
        }
        PhonePanelGeometry full=new PhonePanelGeometry(w,h,edge,2*d);
        float bottom=full.cy+full.wheel;for(int i=0;i<9;i++)bottom=Math.max(bottom,full.y[i]+full.r[i]);
        if(bottom<=h-footer-edge)check(g.cx==full.cx&&g.cy==full.cy&&g.wheel==full.wheel&&java.util.Arrays.equals(g.x,full.x)&&java.util.Arrays.equals(g.y,full.y)&&java.util.Arrays.equals(g.r,full.r),"unchanged V8 geometry");
    }
    private static PhonePanelGeometry test(float w,float h,float d){
        float edge=8*d,eps=.01f;
        PhonePanelGeometry g=new PhonePanelGeometry(w,h,edge,2*d);
        check(g.wheel>0 && g.ok>0 && g.ok<g.wheel,"wheel radii");
        check(g.cx-g.wheel>=edge-eps&&g.cx+g.wheel<=w-edge+eps&&g.cy-g.wheel>=edge-eps&&g.cy+g.wheel<=h-edge+eps,"wheel boundary");
        for(int i=0;i<9;i++){
            float r=g.r[i],x=g.x[i],y=g.y[i];
            check(r>0,"key radius");
            check(x-r>=edge-eps&&x+r<=w-edge+eps&&y-r>=edge-eps&&y+r<=h-edge+eps,"key boundary");
            check(Math.hypot(x-g.cx,y-g.cy)>=r+g.wheel+g.gap-eps,"wheel collision");
            for(int j=i+1;j<9;j++)check(Math.hypot(x-g.x[j],y-g.y[j])>=r+g.r[j]+g.gap-eps,"peripheral collision "+i+"/"+j+" "+w+"x"+h);
            check(g.hitKey(x,y)==i,"key center");
            for(int a=0;a<360;a+=30){
                float px=x+r*.99f*(float)Math.cos(Math.toRadians(a)),py=y+r*.99f*(float)Math.sin(Math.toRadians(a));
                check(g.hitKey(px,py)==i&&g.hitWheel(px,py)==0,"key edge hit");
            }
        }
        float m=(g.ok+g.wheel)/2;
        check(g.hitWheel(g.cx,g.cy)==1&&g.hitWheel(g.cx,g.cy-m)==2&&g.hitWheel(g.cx,g.cy+m)==3&&g.hitWheel(g.cx-m,g.cy)==4&&g.hitWheel(g.cx+m,g.cy)==5,"wheel hit");
        check(g.hitKey(g.cx,g.cy)==-1,"wheel center collision");
        return g;
    }
}

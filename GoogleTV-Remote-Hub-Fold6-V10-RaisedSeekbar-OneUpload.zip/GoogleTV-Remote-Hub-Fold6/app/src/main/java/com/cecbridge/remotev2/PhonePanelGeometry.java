package com.cecbridge.remotev2;

/** Phone viewport geometry. All coordinates are pixels, including the touch regions. */
final class PhonePanelGeometry {
    final float cx,cy,wheel,ok,gap;
    final float[] x=new float[9],y=new float[9],r=new float[9];
    final boolean tall;

    PhonePanelGeometry(float width,float height,float edgeInset,float requestedGap){
        float w=Math.max(0,width-2*edgeInset),h=Math.max(0,height-2*edgeInset);
        // Tall cover displays: stretch the original clockwise sequence into four rows
        // around a wider circular wheel. The wheel and every key stay perfectly round.
        tall=w>0 && h>=1.55f*w;
        if(!tall){
            RoundPanelGeometry base=new RoundPanelGeometry(width,height,edgeInset,requestedGap);
            cx=base.cx;cy=base.cy;wheel=base.wheel;ok=base.ok;gap=base.gap;
            System.arraycopy(base.x,0,x,0,x.length);
            System.arraycopy(base.y,0,y,0,y.length);
            System.arraycopy(base.r,0,r,0,r.length);
            return;
        }
        cx=width/2;cy=height/2;
        wheel=w*.43f;ok=wheel*.34f;
        gap=Math.min(requestedGap,w*.012f);
        // The inner side keys are tangent to the central wheel, then the outer
        // rows sit above/below them. Solve the maximum safe common radius.
        float low=0,high=(w-2*gap)/6f;
        for(int i=0;i<32;i++){
            float m=(low+high)/2;
            if(outerY(w,m)+m<=h/2)low=m;else high=m;
        }
        float q=low*.997f;
        float side=w/2-q, inner=innerY(w,q), outer=outerY(w,q);
        // Same clockwise order as V7: power, settings, right pair, bottom pair,
        // left pair, then the upper-left key. No commands are reassigned.
        float[] dx={0,side,side,side,w*.24f,-w*.24f,-side,-side,-side};
        float[] dy={-outer,-outer,-inner,inner,outer,outer,inner,-inner,-outer};
        for(int i=0;i<9;i++){x[i]=cx+dx[i];y[i]=cy+dy[i];r[i]=q;}
    }
    // V10 footer: 24dp labels, 56dp touch area (48dp on short screens), 4dp padding.
    static int footerHeight(float viewportHeight,float density){
        return Math.round((viewportHeight<420*density?76:84)*density);
    }
    static int footerLift(float viewportHeight,float density){
        return Math.round((viewportHeight<420*density?16:36)*density);
    }
    /** Legacy V9 layout, retained for regression comparisons. */
    static PhonePanelGeometry withFooter(float w,float h,float edge,float gap,float footer){
        PhonePanelGeometry full=new PhonePanelGeometry(w,h,edge,gap);
        float bottom=full.cy+full.wheel;
        for(int i=0;i<full.r.length;i++)bottom=Math.max(bottom,full.y[i]+full.r[i]);
        if(bottom<=h-footer-edge)return full;
        return new PhonePanelGeometry(w,Math.max(2*edge+1,h-footer),edge,gap);
    }
    private float innerY(float w,float radius){
        float d=wheel+radius+gap,dx=w/2-radius;
        // Also reserve vertical separation between the two side rows.
        return Math.max(radius+gap*.5f,(float)Math.sqrt(Math.max(0,d*d-dx*dx)));
    }
    private float outerY(float w,float radius){return innerY(w,radius)+2*radius+gap;}
    int hitKey(float px,float py){
        for(int i=0;i<x.length;i++){
            float dx=px-x[i],dy=py-y[i];
            if(r[i]>0&&dx*dx+dy*dy<=r[i]*r[i])return i;
        }
        return -1;
    }
    int hitWheel(float px,float py){
        if(wheel<=0)return 0;
        float dx=px-cx,dy=py-cy,d2=dx*dx+dy*dy;
        if(d2>wheel*wheel)return 0;
        if(d2<=ok*ok)return 1;
        if(Math.abs(dx)>Math.abs(dy))return dx<0?4:5;
        return dy<0?2:3;
    }
}

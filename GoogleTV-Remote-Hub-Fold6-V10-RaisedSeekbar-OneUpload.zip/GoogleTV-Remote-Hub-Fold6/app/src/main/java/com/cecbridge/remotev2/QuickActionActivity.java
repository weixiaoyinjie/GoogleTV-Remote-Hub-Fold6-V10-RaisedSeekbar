package com.cecbridge.remotev2;
import android.app.Activity;
import android.os.Bundle;
import android.widget.Toast;
/** Compatibility for old pinned power shortcuts. */
public final class QuickActionActivity extends Activity {
    @Override public void onCreate(Bundle state){super.onCreate(state);
        Toast.makeText(this,"旧电源快捷方式已停用，请使用 TV 遥控或 TV 媒体的电源键",Toast.LENGTH_LONG).show();finish();}
}

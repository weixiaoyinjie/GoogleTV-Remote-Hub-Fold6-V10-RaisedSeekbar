package com.cecbridge.remotev2;

import com.cecbridge.remotev2.seek.BridgeWire;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

/** A real media timeline, never synthesized from remote key presses. */
final class TimelineClient {
    static final class State {
        final String id,source,message; final long position,duration; final boolean seekable;
        State(String id,String source,String message,long position,long duration,boolean seekable){
            this.id=id;this.source=source;this.message=message;this.duration=Math.max(0,duration);
            this.position=Math.max(0,Math.min(position,this.duration));this.seekable=seekable&&this.duration>0&&!id.isEmpty();
        }
        static State empty(String message){return new State("","",message,0,0,false);}
        static State from(JSONObject j){return new State(j.optString("id"),j.optString("source"),j.optString("message"),j.optLong("position"),j.optLong("duration"),j.optBoolean("seekable"));}
    }
    static State poll(String host,String mode,String secret)throws Exception{
        if("off".equals(mode)||host.isEmpty())return State.empty("进度未连接");
        if("bridge".equals(mode)){
            if(!secret.matches("[0-9a-f]{32}"))return State.empty("请设置电视进度验证码");
            return State.from(BridgeWire.call(host,secret,new JSONObject().put("op","status")));
        }
        try(Kodi k=new Kodi(host)){return k.state();}
    }
    static State seek(String host,String mode,String secret,State old,int progress)throws Exception{
        long target=Math.round(old.duration*(Math.max(0,Math.min(1000,progress))/1000.0));
        if(!old.seekable)throw new IOException("当前不可定位");
        if("bridge".equals(mode)){
            JSONObject reply=BridgeWire.call(host,secret,new JSONObject().put("op","seek").put("id",old.id).put("position",target));
            if(!reply.optBoolean("accepted"))throw new IOException(reply.optString("message","播放器已改变或拒绝定位"));
            return State.from(reply);
        }
        if(!"kodi".equals(mode))throw new IOException("进度控制已关闭");
        try(Kodi k=new Kodi(host)){
            State current=k.state();if(!current.seekable||!current.id.equals(old.id))throw new IOException("Kodi 播放项目已变化");
            // Kodi JSON-RPC v12 takes an object with a percentage property.
            JSONObject params=new JSONObject().put("playerid",k.player).put("value",new JSONObject().put("percentage",Math.max(0,Math.min(100,target*100.0/current.duration))));
            k.rpc("Player.Seek",params);return k.state();
        }
    }
    private static long millis(JSONObject t){return t==null?0:((t.optLong("hours")*60+t.optLong("minutes"))*60+t.optLong("seconds"))*1000+t.optLong("milliseconds");}
    private static final class Kodi implements AutoCloseable {
        final Socket s=new Socket();final Reader in;final OutputStream out;int seq,player;
        Kodi(String host)throws IOException{
            try{s.connect(new InetSocketAddress(host,9090),900);s.setSoTimeout(1200);in=new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8);out=s.getOutputStream();}
            catch(IOException e){s.close();throw e;}
        }
        Object rpc(String method,JSONObject params)throws Exception{
            int id=++seq;JSONObject req=new JSONObject().put("jsonrpc","2.0").put("method",method).put("id",id);
            if(params!=null)req.put("params",params);
            out.write(req.toString().getBytes(StandardCharsets.UTF_8));out.flush();
            for(int i=0;i<30;i++){
                JSONObject r=new JSONObject(readObject(in));if(r.optInt("id",-1)!=id)continue;
                if(r.has("error"))throw new IOException("Kodi 拒绝 "+method);return r.get("result");
            }
            throw new IOException("Kodi 未返回结果");
        }
        State state()throws Exception{
            JSONArray players=(JSONArray)rpc("Player.GetActivePlayers",null);int count=0;
            for(int i=0;i<players.length();i++){JSONObject p=players.getJSONObject(i);String type=p.optString("type");if("audio".equals(type)||"video".equals(type)){player=p.getInt("playerid");count++;}}
            if(count!=1)return State.empty(count==0?"Kodi 未播放影音":"Kodi 有多个播放器");
            JSONObject p=new JSONObject().put("playerid",player).put("properties",new JSONArray().put("time").put("totaltime").put("canseek"));
            JSONObject props=(JSONObject)rpc("Player.GetProperties",p);
            long duration=millis(props.optJSONObject("totaltime")),position=millis(props.optJSONObject("time"));
            JSONObject item=((JSONObject)rpc("Player.GetItem",new JSONObject().put("playerid",player).put("properties",new JSONArray().put("file")))).getJSONObject("item");
            String id=player+":"+item.optString("type")+":"+item.optString("id")+":"+item.optString("file")+":"+item.optString("label")+":"+duration;
            boolean known=!item.optString("file").isEmpty()||item.has("id")||!item.optString("label").isEmpty();
            return new State(known?id:"","Kodi",props.optBoolean("canseek")?"":"不可定位",position,duration,props.optBoolean("canseek"));
        }
        public void close()throws IOException{s.close();}
    }
    /** Kodi uses concatenated JSON objects, not newline-delimited messages. */
    static String readObject(Reader in)throws IOException{
        StringBuilder b=new StringBuilder();int depth=0;boolean quoted=false,escaped=false;int c;
        while((c=in.read())!=-1){
            if(b.length()==0&&c!='{')continue;
            b.append((char)c);if(b.length()>262144)throw new IOException("Kodi 响应过大");
            if(quoted){if(escaped)escaped=false;else if(c=='\\')escaped=true;else if(c=='"')quoted=false;}
            else if(c=='"')quoted=true;else if(c=='{'||c=='[')depth++;else if(c=='}'||c==']'){if(--depth==0)return b.toString();}
        }
        throw new EOFException("Kodi 连接关闭");
    }
}
